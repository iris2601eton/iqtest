//
//  ShowController.swift
//  iqtest
//
//  Created by User17 on 2018/11/29.
//  Copyright © 2018 User14. All rights reserved.
//

import UIKit
class ShowController: UIViewController {
    @IBOutlet weak var showIQ: UIImageView!
    @IBOutlet weak var labelIQ: UILabel!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var result: UILabel!
    
    var data:Int = 1
    var draw:Int = 1

    func AnimateBounds(iq:Int) {
        let originCenter = self.showIQ.center
        UIView.animate(withDuration: 2,animations: {
                self.showIQ.bounds = CGRect(
                    x: 29, y: 168,
                    width: iq, height: 118)
                self.showIQ.center = originCenter
        })
    }
    
    func AnimateAlpha() {
        UIView.animate(withDuration: 6, animations: {
            self.back.alpha =
                CGFloat(1)
        })
    }
    
    func ShowResult(iq:Int) {
        if(iq < 85){
            self.result.text = "Below average"
        }
        else if(iq >= 85 && iq < 115){
            self.result.text = "Average(68% of test taker)"
        }
        else if(iq >= 115 && iq < 130){
            self.result.text = "Above average"
        }
        else if(iq >= 130 && iq < 145){
            self.result.text = "Gifted(2.3% of test taker)"
        }
        else if(iq >= 145 && iq < 160){
            self.result.text = "Genius(Less than 1% of test taker)"
        }
        else if(iq >= 160){
            self.result.text = "Extraordinary genius"
        }
        
        UIView.animate(withDuration: 2, animations: {
            self.result.alpha =
                CGFloat(1)
        })

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let iq = self.data
        self.draw = iq*178*2/100
        var nowLabelIQ:Int = 0
            Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { (_) in
                if(nowLabelIQ < iq){
                    nowLabelIQ += 1
                    self.labelIQ.text = String(format: "%d", nowLabelIQ)
                }
                else{
                    nowLabelIQ = iq
                    self.labelIQ.text = String(format: "%d", nowLabelIQ)
                }
            }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        AnimateBounds(iq:self.draw)
        AnimateAlpha()
        ShowResult(iq:self.data)
    }
    
}
