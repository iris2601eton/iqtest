//
//  QuizController.swift
//  iqtest
//
//  Created by User14 on 2018/11/28.
//  Copyright © 2018 User14. All rights reserved.
//

import UIKit

class QuizController: UIViewController {
    @IBOutlet weak var Qnum: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet var buttons: [UIButton]!
    @IBOutlet weak var min: UILabel!
    
    struct QA{
        var image:String
        var choice:[String]=[]
        var answer:String
    }
    
    var easy = [QA(image:"easy1.jpg",choice:["A","B","C","D"],answer:"B"),
                     QA(image:"easy2.jpg",choice:["A","B","C","D"],answer:"C"),
                     QA(image:"easy3.jpg",choice:["A","B","C","D"],answer:"B"),
                     QA(image:"easy4.jpg",choice:["600","800","900","500"],answer:"600"),
                     QA(image:"easy5.jpg",choice:["A","B","C","D"],answer:"B"),
                     QA(image:"easy6.jpg",choice:["14","32","64","16"],answer:"14"),
                     QA(image:"easy7.jpg",choice:["A","B","C","D"],answer:"D"),
                     QA(image:"easy8.jpg",choice:["5","9","8","12"],answer:"9"),
                     QA(image:"easy9.jpg",choice:["A","B","C","D"],answer:"C"),
                     QA(image:"easy10.jpg",choice:["A","B","C","D"],answer:"D"),
                     QA(image:"easy11.jpg",choice:["A","B","C","D"],answer:"D")]

    var medium = [QA(image:"medium1.jpg",choice:["82","88","87","243"],answer:"87"),
                QA(image:"medium2.jpg",choice:["555","515","565","646"],answer:"515"),
                QA(image:"medium3.jpg",choice:["A","B","C","D"],answer:"D"),
                QA(image:"medium4.jpg",choice:["A","B","C","D"],answer:"B"),
                QA(image:"medium5.jpg",choice:["15","18","20","23"],answer:"20"),
                QA(image:"medium6.jpg",choice:["A","B","C","D"],answer:"C"),
                QA(image:"medium7.jpg",choice:["40","41","42","43"],answer:"42"),
                QA(image:"medium8.jpg",choice:["12","32","15","14"],answer:"14"),
                QA(image:"medium9.jpg",choice:["A","B","C","D"],answer:"C"),
                QA(image:"medium10.jpg",choice:["A","B","C","D"],answer:"D"),
                QA(image:"medium11.jpg",choice:["A","B","C","D"],answer:"D"),
                QA(image:"medium12.jpg",choice:["1","2","3","0"],answer:"1"),
                QA(image:"medium13.jpg",choice:["6","12","24","48"],answer:"24"),
                QA(image:"medium14.jpg",choice:["A向上，Ｂ向下","A向下，Ｂ向上","AＢ都向上","AＢ都向下"],answer:"A向上，Ｂ向下"),
                QA(image:"medium15.jpg",choice:["2","7","27","36"],answer:"27")]

    var hard = [QA(image:"hard1.jpg",choice:["78","85","98","51"],answer:"98"),
                QA(image:"hard2.jpg",choice:["A","B","C","D"],answer:"C"),
                QA(image:"hard3.jpg",choice:["A","B","C","D"],answer:"B"),
                QA(image:"hard4.jpg",choice:["15","21","30","35"],answer:"30"),
                QA(image:"hard5.jpg",choice:["A","B","C","D"],answer:"C")]

    
    var easyNum = [0,1,2,3,4,5,6,7,8,9,10]
    var mediumNum = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]
    var hardNum = [0,1,2,3,4]
    
    var question_count = 0
    var score = 75
    var right_answer = ""
    var nowTime = 15*60

    
 
    func showQuestion()
    {
        var value:Int = 0
        var random_number:Int = 0
        if(question_count<6){
            random_number = Int(arc4random_uniform(UInt32(easyNum.count)))
            value = easyNum[random_number]
            easyNum.remove(at: random_number)
            img.image = UIImage(named: easy[value].image)
            right_answer = easy[value].answer
            for i in 0..<buttons.count
            {
                buttons[i].setTitle(easy[value].choice[i], for: .normal)
            }
        }
        else if(question_count>=6 && question_count<18){
            random_number = Int(arc4random_uniform(UInt32(mediumNum.count)))
            value = mediumNum[random_number]
            mediumNum.remove(at: random_number)
            img.image = UIImage(named: medium[value].image)
            right_answer = medium[value].answer
            for i in 0..<buttons.count
            {
                buttons[i].setTitle(medium[value].choice[i], for: .normal)
            }
        }
        else if(question_count>=18 && question_count<21){
            random_number = Int(arc4random_uniform(UInt32(hardNum.count)))
            value = hardNum[random_number]
            hardNum.remove(at: random_number)
            img.image = UIImage(named: hard[value].image)
            right_answer = hard[value].answer
            for i in 0..<buttons.count
            {
                buttons[i].setTitle(hard[value].choice[i], for: .normal)
            }
        }
        Qnum.text = "第\(question_count+1)題"
    }
    
    @IBAction func choose(_ sender: UIButton){
        if(sender.currentTitle == right_answer){
            if(question_count<6){
                score += 2
            }
            else if(question_count>=6 && question_count<18){
                score += 5
            }
            else if(question_count>=18 && question_count<21){
                score += 11
            }
        }
        question_count += 1
        if(question_count >= 21){
            performSegue(withIdentifier: "toShow", sender: nil)
        }
        else{
            showQuestion()
        }
        
    }
    
    
    func show_alertController()
    {
        //make an alertController
        let alertController = UIAlertController(
            title: "時間到",
            message: "跳轉到結果頁面",
            preferredStyle: .alert)
        
        //make[確認]button
        let okAction = UIAlertAction(
            title: "確認",
            style: .default,
            handler:{
                (action: UIAlertAction!) -> Void in
        })
        alertController.addAction(okAction)
        
        //show the alertController
        self.present(alertController, animated: true, completion: nil)
    }
    
    func initialize()
    {
        easyNum = [0,1,2,3,4,5,6,7,8,9,10]
        mediumNum = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]
        hardNum = [0,1,2,3,4]
        question_count = 0
        score = 75
        nowTime = 15*60
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if(question_count>=21){
            return true
        }
        else if(nowTime==0){
            return true
        }
        else{
            return false
        }
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as?ShowController
        destination?.data = self.score
    }
 
    
    override func viewDidLoad() {
        initialize()
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (_) in
            self.nowTime -= 1
            self.min.text = "\(String(format:"%.2d",self.nowTime/60)):\(String(format:"%.2d",self.nowTime%60))"
            if(self.nowTime == 0){
                self.performSegue(withIdentifier: "toShow", sender: nil)
            }
            else if(self.nowTime == 2){
                self.show_alertController()
            }
            else if(self.nowTime < 0){
                self.nowTime = 0
            }
        }
        showQuestion()
        super.viewDidLoad()
    }
    
    
}

