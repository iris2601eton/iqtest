//
//  ViewController.swift
//  iqtest
//
//  Created by User14 on 2018/11/21.
//  Copyright © 2018 User14. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

